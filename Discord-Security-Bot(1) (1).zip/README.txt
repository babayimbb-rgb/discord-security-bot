# Discord Security Bot

Bu bot Node.js + discord.js ile çalışır. Python gerekmez.

## Özellikler
- `/security` Discord içi panel
- Anti role abuse: yetkisiz rol verme/kendine rol verme algılanınca işlemi yapanın kaldırılabilen rolleri alınır
- Kanal oluşturma/silme koruması
- Rol oluşturma/silme koruması
- Ban/kick işlemini yapan şüpheli kişinin rolleri alınır
- Whitelist mantığı
- Log kanalı desteği için altyapı
- Şüpheli kişi BANLANMAZ

## ÖNEMLİ
Botun kendisi bir yerde çalışmak zorundadır. Bu klasör doğrudan Discord'a yüklenen bir dosya değildir.

## Gerekli Discord bot izinleri
En kolay kurulum için botu sunucuna Administrator yetkisiyle ekle.
Botun rolünü, koruyacağı üyelerin rollerinin üstüne taşı.

Developer Portal'da:
- Server Members Intent: ON
- View Audit Log
- Manage Roles
- Manage Channels
- Ban Members (gerekli değil ama audit log kontrolleri için yönetici kullanmak kolaydır)
- Kick Members (gerekli değil)
- Send Messages
- Embed Links

## Kurulum
1. Discord Developer Portal'dan bir Application/Bot oluştur.
2. Bot Token'ı al.
3. `.env.example` dosyasını `.env` olarak kopyala.
4. DISCORD_TOKEN değerine bot tokenını yaz.
5. OWNER_ID değerine kendi Discord kullanıcı ID'ni yaz.
6. Node.js kurulu bilgisayarda klasörde:
   npm install
   npm start
7. Botu OAuth2 URL ile sunucuna ekle.
8. Discord'da `/security` yaz.

## Güvenlik
Bot tokenını kimseyle paylaşma. Token sızarsa Developer Portal'dan hemen yenile.

## Not
Ayarlar şu sürümde RAM'de tutulur; bot yeniden başlarsa whitelist/ayarlar sıfırlanır.
