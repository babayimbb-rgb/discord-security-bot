require("dotenv").config();

const {
  Client,
  GatewayIntentBits,
  PermissionsBitField,
  AuditLogEvent,
  REST,
  Routes,
  SlashCommandBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
  Events
} = require("discord.js");

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers
  ]
});

// Memory-based settings. They reset if the bot restarts.
// For a permanent database, replace this with SQLite/PostgreSQL later.
const settings = new Map();

function getSettings(guildId) {
  if (!settings.has(guildId)) {
    settings.set(guildId, {
      enabled: true,
      whitelist: new Set(),
      logChannelId: null
    });
  }
  return settings.get(guildId);
}

function isOwnerOrAdmin(interaction) {
  return interaction.user.id === process.env.OWNER_ID ||
    interaction.member?.permissions?.has(PermissionsBitField.Flags.Administrator);
}

async function punishExecutor(guild, userId, reason) {
  const member = await guild.members.fetch(userId).catch(() => null);
  if (!member || member.user.bot) return false;

  // Never touch the server owner.
  if (member.id === guild.ownerId) return false;

  const me = guild.members.me;
  if (!me) return false;

  // Remove every role the bot can remove. @everyone cannot be removed.
  const removable = member.roles.cache.filter(
    role => role.id !== guild.id &&
      !role.managed &&
      role.position < me.roles.highest.position
  );

  if (removable.size) {
    await member.roles.remove(removable, reason).catch(() => {});
  }

  const s = getSettings(guild.id);
  if (s.logChannelId) {
    const ch = guild.channels.cache.get(s.logChannelId);
    if (ch?.isTextBased()) {
      const embed = new EmbedBuilder()
        .setTitle("🚨 SECURITY ACTION")
        .setDescription(`**${member.user.tag}** adlı kullanıcının kaldırılabilen rolleri alındı.`)
        .addFields({ name: "Sebep", value: reason })
        .setTimestamp();
      await ch.send({ embeds: [embed] }).catch(() => {});
    }
  }
  return true;
}

async function getExecutor(guild, type) {
  const logs = await guild.fetchAuditLogs({ type, limit: 5 }).catch(() => null);
  if (!logs) return null;

  const now = Date.now();
  const entry = logs.entries.find(e =>
    e.executor &&
    !e.executor.bot &&
    now - e.createdTimestamp < 10000
  );
  return entry?.executor ?? null;
}

async function securityAction(guild, executor, reason) {
  if (!executor || executor.bot) return;
  const s = getSettings(guild.id);
  if (!s.enabled || s.whitelist.has(executor.id) || executor.id === process.env.OWNER_ID) return;
  await punishExecutor(guild, executor.id, reason);
}

const commands = [
  new SlashCommandBuilder()
    .setName("security")
    .setDescription("Security bot panelini açar.")
].map(c => c.toJSON());

client.once(Events.ClientReady, async () => {
  console.log(`Security bot hazır: ${client.user.tag}`);

  const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);
  await rest.put(
    Routes.applicationCommands(client.user.id),
    { body: commands }
  );
});

client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand() && !interaction.isButton()) return;

  if (interaction.isChatInputCommand() && interaction.commandName === "security") {
    if (!isOwnerOrAdmin(interaction)) {
      return interaction.reply({ content: "❌ Bu paneli sadece yönetici açabilir.", ephemeral: true });
    }

    const s = getSettings(interaction.guild.id);
    const embed = new EmbedBuilder()
      .setTitle("🛡️ Security Panel")
      .setDescription(
        `Koruma: **${s.enabled ? "AÇIK 🟢" : "KAPALI 🔴"}**\n` +
        `Whitelist: **${s.whitelist.size} kişi**\n\n` +
        `Yetkisiz rol işlemi, kanal silme/oluşturma, mesaj toplu silme ve ban/kick işlemleri izlenir.`
      );

    const row = new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId("sec_toggle")
        .setLabel(s.enabled ? "Korumayı Kapat" : "Korumayı Aç")
        .setStyle(s.enabled ? ButtonStyle.Danger : ButtonStyle.Success),
      new ButtonBuilder()
        .setCustomId("sec_whitelist")
        .setLabel("Whitelist Bilgisi")
        .setStyle(ButtonStyle.Primary)
    );

    return interaction.reply({ embeds: [embed], components: [row] });
  }

  if (interaction.isButton()) {
    if (!isOwnerOrAdmin(interaction)) {
      return interaction.reply({ content: "❌ Yetkin yok.", ephemeral: true });
    }

    const s = getSettings(interaction.guild.id);

    if (interaction.customId === "sec_toggle") {
      s.enabled = !s.enabled;
      return interaction.update({
        content: `Koruma **${s.enabled ? "açıldı 🟢" : "kapatıldı 🔴"}**.`,
        embeds: [],
        components: []
      });
    }

    if (interaction.customId === "sec_whitelist") {
      const names = [...s.whitelist].map(id => `<@${id}>`).join(", ") || "Whitelist boş.";
      return interaction.reply({ content: `**Whitelist:** ${names}`, ephemeral: true });
    }
  }
});

// Someone adds/removes roles from a member.
client.on(Events.GuildMemberUpdate, async (oldMember, newMember) => {
  const added = newMember.roles.cache.filter(r => !oldMember.roles.cache.has(r.id));
  const removed = oldMember.roles.cache.filter(r => !newMember.roles.cache.has(r.id));

  if (!added.size && !removed.size) return;

  // Give audit log a moment to register the action.
  setTimeout(async () => {
    const executor = await getExecutor(newMember.guild, AuditLogEvent.MemberRoleUpdate);
    if (!executor) return;

    const s = getSettings(newMember.guild.id);
    if (!s.enabled || s.whitelist.has(executor.id) || executor.id === process.env.OWNER_ID) return;

    // Ignore changes performed by the security bot itself.
    if (executor.id === client.user.id) return;

    await securityAction(
      newMember.guild,
      executor,
      `Yetkisiz rol değişikliği: ${newMember.user.tag}`
    );
  }, 800);
});

// Channel deleted.
client.on(Events.ChannelDelete, async channel => {
  if (!channel.guild) return;
  setTimeout(async () => {
    const executor = await getExecutor(channel.guild, AuditLogEvent.ChannelDelete);
    await securityAction(channel.guild, executor, `Kanal silme: #${channel.name}`);
  }, 800);
});

// Channel created.
client.on(Events.ChannelCreate, async channel => {
  if (!channel.guild) return;
  setTimeout(async () => {
    const executor = await getExecutor(channel.guild, AuditLogEvent.ChannelCreate);
    await securityAction(channel.guild, executor, `Yetkisiz kanal oluşturma: #${channel.name}`);
  }, 800);
});

// Role deleted.
client.on(Events.RoleDelete, async role => {
  setTimeout(async () => {
    const executor = await getExecutor(role.guild, AuditLogEvent.RoleDelete);
    await securityAction(role.guild, executor, `Rol silme: ${role.name}`);
  }, 800);
});

// Role created.
client.on(Events.RoleCreate, async role => {
  setTimeout(async () => {
    const executor = await getExecutor(role.guild, AuditLogEvent.RoleCreate);
    await securityAction(role.guild, executor, `Rol oluşturma: ${role.name}`);
  }, 800);
});

// Ban event: punish the person who issued the ban, not the banned user.
client.on(Events.GuildBanAdd, async ban => {
  setTimeout(async () => {
    const executor = await getExecutor(ban.guild, AuditLogEvent.MemberBanAdd);
    await securityAction(ban.guild, executor, `Üye banlama işlemi: ${ban.user.tag}`);
  }, 800);
});

// Kick event: punish the person who issued the kick.
client.on(Events.GuildMemberRemove, async member => {
  setTimeout(async () => {
    const executor = await getExecutor(member.guild, AuditLogEvent.MemberKick);
    await securityAction(member.guild, executor, `Üye atma işlemi: ${member.user.tag}`);
  }, 800);
});

client.login(process.env.DISCORD_TOKEN);
